# -*- coding: utf-8 -*-
"""
Drone Flight Planner - Plugin QGIS
Entry point richiesto da QGIS per caricare il plugin.
"""


def classFactory(iface):
    from .plugin import DroneFlightPlannerPlugin
    return DroneFlightPlannerPlugin(iface)
