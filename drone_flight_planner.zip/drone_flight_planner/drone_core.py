# -*- coding: utf-8 -*-
"""
drone_core.py
=============
Logica di pianificazione volo drone, senza dipendenze da CLI o QGIS.
Può essere usata sia dallo script a riga di comando che dal plugin QGIS.
"""

import math
import xml.etree.ElementTree as ET

import numpy as np
from pyproj import CRS, Transformer
import rasterio
from shapely.geometry import LineString, Polygon


# ---------------------------------------------------------------------------
# KML parsing
# ---------------------------------------------------------------------------

KML_NS = "http://www.opengis.net/kml/2.2"


def parse_kml_polygon(kml_path: str) -> Polygon:
    """Estrae il primo poligono trovato nel file KML (coordinate lon/lat WGS84)."""
    tree = ET.parse(kml_path)
    root = tree.getroot()

    coords_text = None
    for elem in root.iter(f"{{{KML_NS}}}coordinates"):
        coords_text = elem.text.strip()
        break
    if coords_text is None:
        for elem in root.iter("coordinates"):
            coords_text = elem.text.strip()
            break
    if coords_text is None:
        raise ValueError(f"Nessuna geometria poligonale trovata in {kml_path}.")

    coords = []
    for token in coords_text.split():
        parts = token.split(",")
        lon, lat = float(parts[0]), float(parts[1])
        coords.append((lon, lat))
    return Polygon(coords)


def qgis_layer_to_polygon(layer) -> Polygon:
    """
    Converte il primo feature di un QgsVectorLayer in un Polygon shapely (WGS84).
    """
    from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject

    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    layer_crs = layer.crs()
    transform = QgsCoordinateTransform(layer_crs, wgs84, QgsProject.instance())

    for feature in layer.getFeatures():
        geom = feature.geometry()
        geom.transform(transform)
        # Trasforma in WKT e poi in shapely
        wkt = geom.asWkt()
        from shapely import wkt as swkt
        return swkt.loads(wkt)

    raise ValueError("Il layer non contiene feature valide.")


# ---------------------------------------------------------------------------
# KML output
# ---------------------------------------------------------------------------

def write_kml(
    output_path: str,
    full_path: list,
    agl: float,
    fov: float,
    overlap: float,
    sidelap: float,
    epsg_used: int,
    heading: float,
):
    """
    Scrive il KML 3D con altitudeMode=absolute.

    full_path  : lista unica continua [(lon,lat,alt), ...] con raccordi inclusi
    """
    kml = ET.Element("kml", xmlns=KML_NS)
    doc = ET.SubElement(kml, "Document")
    ET.SubElement(doc, "name").text = "Piano di volo drone"
    ET.SubElement(doc, "description").text = (
        f"EPSG:{epsg_used} | AGL: {agl} m | FOV: {fov}° | Heading: {heading}° "
        f"| Overlap: {overlap}% | Sidelap: {sidelap}%"
    )

    # Stile linea di volo (blu)
    style_main = ET.SubElement(doc, "Style", id="mainStyle")
    ls = ET.SubElement(style_main, "LineStyle")
    ET.SubElement(ls, "color").text = "ffff0000"
    ET.SubElement(ls, "width").text = "3"

    # Unico elemento: percorso drone completo
    pm = ET.SubElement(doc, "Placemark")
    ET.SubElement(pm, "name").text = "Percorso drone completo"
    ET.SubElement(pm, "styleUrl").text = "#mainStyle"
    ln = ET.SubElement(pm, "LineString")
    ET.SubElement(ln, "extrude").text = "0"
    ET.SubElement(ln, "tessellate").text = "1"
    ET.SubElement(ln, "altitudeMode").text = "absolute"
    ET.SubElement(ln, "coordinates").text = " ".join(
        f"{lon},{lat},{alt:.2f}" for lon, lat, alt in full_path
    )

    tree = ET.ElementTree(kml)
    ET.indent(tree, space="  ")
    tree.write(output_path, xml_declaration=True, encoding="UTF-8")



# ---------------------------------------------------------------------------
# Quota relativa al decollo
# ---------------------------------------------------------------------------

def rebase_altitudes(full_path: list, agl: float) -> list:
    """
    Ricalcola le quote del percorso in modo che:
      - il primo punto abbia quota = agl
      - ogni punto successivo = quota_precedente + (dtm[i] - dtm[i-1])

    In pratica le quote sono espresse come variazioni cumulative
    della quota del terreno rispetto al punto di partenza,
    traslate in modo che il primo punto parta esattamente ad AGL.

    Questo produce un KML dove altitudeMode=relativeToGround è opzionale
    ma le quote numeriche seguono il profilo del terreno con offset AGL
    calcolato a partire dal punto di decollo.
    """
    if not full_path:
        return full_path

    # Le quote in full_path sono già: elev_dtm[i] + agl
    # Quindi dtm[i] = alt[i] - agl per qualsiasi punto.
    # Vogliamo:
    #   q[0] = agl
    #   q[i] = q[i-1] + (dtm[i] - dtm[i-1])
    #        = q[i-1] + (alt[i] - alt[i-1])   (perché agl si cancella)
    # Ovvero: q[i] = agl + (alt[i] - alt[0])
    # È una semplice traslazione che porta alt[0] → agl.

    alt0 = full_path[0][2]
    return [(lon, lat, agl + (alt - alt0)) for lon, lat, alt in full_path]


# ---------------------------------------------------------------------------
# CRS resolution
# ---------------------------------------------------------------------------

def resolve_crs(dtm_src, forced_epsg=None):
    """Restituisce (pyproj.CRS, epsg_int). Gestisce DTM con CRS unnamed."""
    if forced_epsg:
        return CRS.from_epsg(forced_epsg), forced_epsg

    rio_crs = dtm_src.crs

    try:
        epsg = rio_crs.to_epsg()
        if epsg:
            return CRS.from_epsg(epsg), epsg
    except Exception:
        pass

    try:
        crs = CRS.from_wkt(rio_crs.to_wkt())
        epsg = crs.to_epsg()
        if epsg:
            return crs, epsg
    except Exception:
        pass

    # Autodetect da bounds
    bounds = dtm_src.bounds
    cx = (bounds.left + bounds.right) / 2
    cy = (bounds.bottom + bounds.top) / 2
    if 200_000 < cx < 900_000 and 3_000_000 < cy < 7_000_000:
        return CRS.from_epsg(32633), 32633

    raise RuntimeError(
        "CRS del DTM non determinabile. Specifica un codice EPSG manualmente."
    )


# ---------------------------------------------------------------------------
# DTM Sampler
# ---------------------------------------------------------------------------

class DTMSampler:
    MAX_SEARCH_RADIUS = 20

    def __init__(self, dtm_path: str, forced_epsg=None, log_fn=None):
        """
        log_fn: funzione di logging opzionale, es. QgsMessageLog.logMessage o print.
        """
        self._log = log_fn or print
        self.src = rasterio.open(dtm_path)
        self.crs_proj, self.epsg = resolve_crs(self.src, forced_epsg)

        self.wgs84_to_dtm = Transformer.from_crs(CRS.from_epsg(4326), self.crs_proj, always_xy=True)
        self.dtm_to_wgs84 = Transformer.from_crs(self.crs_proj, CRS.from_epsg(4326), always_xy=True)

        self._data = self.src.read(1).astype(float)
        raw_nodata = self.src.nodata
        self._nodata_val = float(raw_nodata) if raw_nodata is not None else None
        self._valid = self._make_valid_mask()

        n_invalid = int((~self._valid).sum())
        if n_invalid:
            self._log(f"DTM: {n_invalid} pixel non validi ({100*n_invalid/self._valid.size:.2f}%)")

    def _make_valid_mask(self):
        mask = np.ones(self._data.shape, dtype=bool)
        if self._nodata_val is not None:
            mask &= (self._data != self._nodata_val)
        mask &= (self._data > 0)
        return mask

    def _fill_by_neighbours(self, row, col):
        h, w = self._data.shape
        for r in range(1, self.MAX_SEARCH_RADIUS + 1):
            neighbours = []
            for dr in range(-r, r + 1):
                for dc in range(-r, r + 1):
                    if abs(dr) != r and abs(dc) != r:
                        continue
                    nr, nc = row + dr, col + dc
                    if 0 <= nr < h and 0 <= nc < w and self._valid[nr, nc]:
                        dist = math.hypot(dr, dc)
                        neighbours.append((self._data[nr, nc], dist))
            if neighbours:
                total_w = sum(1.0 / d for _, d in neighbours)
                return sum(v / d for v, d in neighbours) / total_w
        return None

    def elevation(self, x, y):
        try:
            row, col = self.src.index(x, y)
        except Exception:
            return None
        h, w = self._data.shape
        row = max(0, min(row, h - 1))
        col = max(0, min(col, w - 1))
        val = self._data[row, col]
        if self._valid[row, col]:
            return float(val)
        return self._fill_by_neighbours(row, col)

    @staticmethod
    def fill_gaps_along_line(pts):
        elevs = [p[2] for p in pts]
        valid_idx = [i for i, e in enumerate(elevs) if e is not None]
        if not valid_idx:
            return [(x, y, 0.0) for x, y, _ in pts]
        filled = list(elevs)
        for seg_start, seg_end in zip(valid_idx, valid_idx[1:]):
            if seg_end - seg_start <= 1:
                continue
            v0, v1 = filled[seg_start], filled[seg_end]
            for i in range(seg_start + 1, seg_end):
                t = (i - seg_start) / (seg_end - seg_start)
                filled[i] = v0 + t * (v1 - v0)
        first_valid = valid_idx[0]
        for i in range(first_valid):
            filled[i] = filled[first_valid]
        last_valid = valid_idx[-1]
        for i in range(last_valid + 1, len(filled)):
            filled[i] = filled[last_valid]
        return [(pts[i][0], pts[i][1], float(filled[i])) for i in range(len(pts))]

    def sample_line(self, pts_utm, step_m=5.0):
        result = []
        for i in range(len(pts_utm) - 1):
            x0, y0 = pts_utm[i]
            x1, y1 = pts_utm[i + 1]
            dist = math.hypot(x1 - x0, y1 - y0)
            n = max(1, int(dist / step_m))
            for j in range(n):
                t = j / n
                result.append((x0 + t*(x1-x0), y0 + t*(y1-y0), self.elevation(x0 + t*(x1-x0), y0 + t*(y1-y0))))
        x1, y1 = pts_utm[-1]
        result.append((x1, y1, self.elevation(x1, y1)))
        return self.fill_gaps_along_line(result)

    def close(self):
        self.src.close()


# ---------------------------------------------------------------------------
# Flight path generation
# ---------------------------------------------------------------------------

def calc_strip_spacing(agl, fov_deg, sidelap_pct):
    swath = 2.0 * agl * math.tan(math.radians(fov_deg) / 2.0)
    return swath * (1.0 - sidelap_pct / 100.0), swath


def calc_wp_spacing(agl, fov_deg, overlap_pct):
    footprint = 2.0 * agl * math.tan(math.radians(fov_deg) / 2.0)
    return max(footprint * (1.0 - overlap_pct / 100.0), 1.0)


def _rotate_polygon(area_utm: Polygon, angle_deg: float) -> tuple:
    """
    Ruota il poligono UTM attorno al suo centroide di -angle_deg gradi
    (così le strisciate orizzontali nel sistema ruotato corrispondono
    all'heading richiesto nel sistema originale).
    Restituisce (poligono_ruotato, centroide_x, centroide_y, angolo_rad).
    """
    cx, cy = area_utm.centroid.x, area_utm.centroid.y
    theta = math.radians(-angle_deg)   # rotazione inversa
    cos_t, sin_t = math.cos(theta), math.sin(theta)

    def rotate_pt(x, y):
        dx, dy = x - cx, y - cy
        return cx + dx * cos_t - dy * sin_t, cy + dx * sin_t + dy * cos_t

    new_coords = [rotate_pt(x, y) for x, y in area_utm.exterior.coords]
    return Polygon(new_coords), cx, cy, theta


def _unrotate_pt(x, y, cx, cy, theta):
    """Ruota il punto (x,y) di +theta attorno a (cx,cy) — operazione inversa."""
    cos_t, sin_t = math.cos(-theta), math.sin(-theta)
    dx, dy = x - cx, y - cy
    return cx + dx * cos_t - dy * sin_t, cy + dx * sin_t + dy * cos_t


def generate_strips(area_lonlat, dtm, agl, fov_deg, overlap_pct, sidelap_pct,
                    sample_step_m, heading_deg=0.0):
    """
    Genera strisciate di volo nell'area con heading configurabile.

    heading_deg : direzione delle strisciate in gradi geografici (0=N, 90=E, 180=S, 270=W).
                  Le strisciate saranno parallele a questa direzione.
                  Es: 0 → strisciate N-S (il drone vola Nord-Sud)
                      90 → strisciate E-W (classico)
    """
    lons, lats = area_lonlat.exterior.coords.xy
    xs, ys = dtm.wgs84_to_dtm.transform(list(lons), list(lats))
    area_utm = Polygon(zip(xs, ys))

    s_sp, swath = calc_strip_spacing(agl, fov_deg, sidelap_pct)
    wp_sp = calc_wp_spacing(agl, fov_deg, overlap_pct)

    # Ruota l'area per generare strisciate orizzontali nell'asse ruotato.
    # heading 0° (Nord) → theta = 0° → strisciate E-W nel sistema ruotato = N-S reale
    # heading 90° (Est) → strisciate orizzontali nel sistema ruotato = E-W reale
    # Convenzione: heading è la direzione di volo lungo la strisciata.
    # Le strisciate sono perpendicolari alla direzione di avanzamento laterale,
    # quindi ruotiamo di (heading - 90°) per allineare le scan-line con heading.
    rot_angle = heading_deg - 90.0
    area_rot, cx, cy, theta = _rotate_polygon(area_utm, rot_angle)

    min_x, min_y, max_x, max_y = area_rot.bounds

    strips = []
    y = min_y + s_sp / 2.0
    idx = 0

    while y <= max_y + s_sp / 2.0:
        # Scan line orizzontale nel sistema ruotato
        scan = LineString([(min_x - 10, y), (max_x + 10, y)])
        clipped = scan.intersection(area_rot)

        if clipped.is_empty:
            y += s_sp
            continue

        geoms = list(clipped.geoms) if clipped.geom_type == "MultiLineString" else [clipped]

        for seg in geoms:
            if seg.is_empty or seg.length < 1:
                continue
            coords = list(seg.coords)
            x0, y0 = coords[0]
            x1, y1 = coords[-1]

            # Serpentina
            if idx % 2 == 1:
                x0, x1 = x1, x0
                y0, y1 = y1, y0

            dist = math.hypot(x1 - x0, y1 - y0)
            n_wp = max(2, int(dist / wp_sp) + 1)

            # Punti nel sistema ruotato → riporta nel sistema UTM originale
            pts_utm = []
            for i in range(n_wp):
                t = i / (n_wp - 1)
                xr = x0 + (x1 - x0) * t
                yr = y0 + (y1 - y0) * t
                xu, yu = _unrotate_pt(xr, yr, cx, cy, theta)
                pts_utm.append((xu, yu))

            sampled = dtm.sample_line(pts_utm, step_m=sample_step_m)
            strip = []
            for xu, yu, elev in sampled:
                lon, lat = dtm.dtm_to_wgs84.transform(xu, yu)
                strip.append((lon, lat, elev + agl))
            strips.append(strip)
            idx += 1

        y += s_sp

    return strips, swath, s_sp, wp_sp


def connect_strips(strips: list, dtm: "DTMSampler", agl: float, sample_step_m: float) -> list:
    """
    Collega le strisciate con segmenti di raccordo campionati sul DTM,
    producendo un'unica sequenza continua di punti (lon, lat, alt).

    Il raccordo va dall'ultimo punto della strisciata i al primo della i+1,
    campionato ogni sample_step_m metri in coordinate UTM.
    """
    if not strips:
        return []

    full_path = list(strips[0])  # parte dalla prima strisciata

    for i in range(1, len(strips)):
        prev_end = strips[i - 1][-1]   # (lon, lat, alt) — ultimo punto strisciata precedente
        next_start = strips[i][0]       # (lon, lat, alt) — primo punto strisciata successiva

        # Converti in UTM per campionare il DTM
        x0, y0 = dtm.wgs84_to_dtm.transform(prev_end[0], prev_end[1])
        x1, y1 = dtm.wgs84_to_dtm.transform(next_start[0], next_start[1])

        dist = math.hypot(x1 - x0, y1 - y0)
        if dist > sample_step_m:
            # Campiona il tratto di raccordo
            connector_utm = []
            n = max(2, int(dist / sample_step_m))
            for j in range(1, n):          # escludi primo (già in full_path) e ultimo
                t = j / n
                connector_utm.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))

            sampled = dtm.fill_gaps_along_line(
                [(x, y, dtm.elevation(x, y)) for x, y in connector_utm]
            )
            for xu, yu, elev in sampled:
                lon, lat = dtm.dtm_to_wgs84.transform(xu, yu)
                full_path.append((lon, lat, elev + agl))

        # Aggiungi la strisciata successiva
        full_path.extend(strips[i])

    return full_path


# ---------------------------------------------------------------------------
# Smoothing — implementazione pura numpy, senza scipy
# ---------------------------------------------------------------------------

def _gaussian_kernel(sigma_px: float) -> np.ndarray:
    """
    Crea un kernel gaussiano 1D normalizzato.
    Raggio = ceil(3 * sigma) per coprire il 99.7% della distribuzione.
    """
    radius = max(1, int(np.ceil(3.0 * sigma_px)))
    x = np.arange(-radius, radius + 1, dtype=float)
    kernel = np.exp(-0.5 * (x / sigma_px) ** 2)
    return kernel / kernel.sum()


def _convolve1d_reflect(signal: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    """
    Convoluzione 1D con padding 'reflect' ai bordi (equivalente a
    scipy.ndimage.gaussian_filter1d con mode='reflect').
    Usa solo numpy, nessuna dipendenza esterna.
    """
    half = len(kernel) // 2
    # Padding reflect: rispecchia il segnale ai bordi
    padded = np.pad(signal, half, mode="reflect")
    # Convoluzione tramite np.convolve (solo numpy)
    result = np.convolve(padded, kernel, mode="valid")
    # np.convolve 'valid' con padding half restituisce esattamente len(signal) elementi
    return result[:len(signal)]


def smooth_strip(strip, sigma_m, step_m):
    """
    Smoothing gaussiano 1D sulle quote di una strisciata.
    Implementato con numpy puro — nessuna dipendenza da scipy.
    """
    if sigma_m <= 0 or len(strip) < 3:
        return strip
    sigma_px = max(sigma_m / step_m, 0.5)
    kernel   = _gaussian_kernel(sigma_px)
    elevs    = np.array([pt[2] for pt in strip], dtype=float)
    smoothed = _convolve1d_reflect(elevs, kernel)
    return [(strip[i][0], strip[i][1], float(smoothed[i])) for i in range(len(strip))]


def smooth_all_strips(strips, sigma_m, step_m):
    """Smoothing per strisciata singola (retrocompatibilità)."""
    if sigma_m <= 0:
        return strips
    return [smooth_strip(s, sigma_m, step_m) for s in strips]


def smooth_path(path, sigma_m, step_m):
    """
    Smoothing gaussiano sull'intero percorso continuo (raccordi inclusi).
    Da usare DOPO connect_strips, così ogni punto — strisciata o raccordo —
    viene ammorbidito con lo stesso filtro.
    """
    if sigma_m <= 0 or len(path) < 3:
        return path
    sigma_px = max(sigma_m / step_m, 0.5)
    kernel   = _gaussian_kernel(sigma_px)
    elevs    = np.array([pt[2] for pt in path], dtype=float)
    smoothed = _convolve1d_reflect(elevs, kernel)
    return [(path[i][0], path[i][1], float(smoothed[i])) for i in range(len(path))]



# ---------------------------------------------------------------------------
# Entry point unico per CLI e plugin
# ---------------------------------------------------------------------------

def run_planning(
    dtm_path: str,
    area_polygon: Polygon,
    output_kml: str,
    agl: float = 50.0,
    fov_deg: float = 70.0,
    overlap_pct: float = 70.0,
    sidelap_pct: float = 70.0,
    step_m: float = 5.0,
    smooth_m: float = 30.0,
    heading_deg: float = 90.0,
    forced_epsg: int = None,
    log_fn=None,
    progress_fn=None,
) -> dict:
    """
    Funzione principale richiamabile sia da CLI che dal plugin QGIS.

    heading_deg    : direzione di volo in gradi geografici (0=Nord, 90=Est)
    """
    log = log_fn or print
    progress = progress_fn or (lambda v: None)

    log("Apertura DTM...")
    progress(5)
    dtm = DTMSampler(dtm_path, forced_epsg=forced_epsg, log_fn=log)

    log(f"Generazione strisciate (heading={heading_deg}°)...")
    progress(20)
    strips, swath, s_sp, wp_sp = generate_strips(
        area_lonlat=area_polygon,
        dtm=dtm,
        agl=agl,
        fov_deg=fov_deg,
        overlap_pct=overlap_pct,
        sidelap_pct=sidelap_pct,
        sample_step_m=step_m,
        heading_deg=heading_deg,
    )

    if not strips:
        dtm.close()
        raise RuntimeError(
            "Nessuna strisciata generata. "
            "Verifica che area e DTM si sovrappongano geograficamente."
        )

    progress(60)
    log(f"Strisciate generate: {len(strips)}, waypoint: {sum(len(s) for s in strips)}")

    progress(72)
    log("Collegamento strisciate in percorso continuo...")
    full_path = connect_strips(strips, dtm=dtm, agl=agl, sample_step_m=step_m)
    log(f"Percorso continuo: {len(full_path)} punti totali")

    if smooth_m > 0:
        log(f"Smoothing gaussiano sull'intero percorso (sigma={smooth_m} m)...")
        full_path = smooth_path(full_path, sigma_m=smooth_m, step_m=step_m)

    progress(88)
    log("Ricalcolo quote relative al punto di decollo...")
    full_path = rebase_altitudes(full_path, agl=agl)

    log("Scrittura KML...")
    write_kml(
        output_path=output_kml,
        full_path=full_path,
        agl=agl,
        fov=fov_deg,
        overlap=overlap_pct,
        sidelap=sidelap_pct,
        epsg_used=dtm.epsg,
        heading=heading_deg,
    )

    all_alts = [pt[2] for pt in full_path]
    stats = {
        "strips":       len(strips),
        "waypoints":    len(full_path),
        "alt_min":      min(all_alts),
        "alt_max":      max(all_alts),
        "alt_delta":    max(all_alts) - min(all_alts),
        "swath_m":      swath,
        "strip_sp_m":   s_sp,
        "wp_sp_m":      wp_sp,
        "epsg":         dtm.epsg,
    }

    dtm.close()
    progress(100)
    return stats
