# -*- coding: utf-8 -*-
"""
plugin.py
=========
Classe principale del plugin QGIS Drone Flight Planner.
Registra il menu e lancia il dialog.
"""

import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsMessageLog, Qgis


class DroneFlightPlannerPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.dialog = None
        self.action = None
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icons", "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Drone Flight Planner", self.iface.mainWindow())
        self.action.setToolTip("Pianifica volo drone a quota costante sul terreno")
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Drone Flight Planner", self.action)

    def unload(self):
        self.iface.removePluginMenu("&Drone Flight Planner", self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.dialog:
            self.dialog.close()

    def run(self):
        from .dialog import DroneFlightPlannerDialog
        if self.dialog is None:
            self.dialog = DroneFlightPlannerDialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
