# -*- coding: utf-8 -*-
"""
dialog.py
=========
Interfaccia grafica del plugin Drone Flight Planner.
Costruita con PyQt5 puro (niente .ui file) per semplicità di distribuzione.
"""

import os
import traceback

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QGroupBox, QLabel, QLineEdit, QPushButton,
    QDoubleSpinBox, QSpinBox, QComboBox, QFileDialog,
    QProgressBar, QTextEdit, QDialogButtonBox,
    QSizePolicy, QCheckBox, QTabWidget, QWidget,
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont
from qgis.core import (
    QgsProject, QgsMapLayerProxyModel, QgsVectorLayer,
    QgsMessageLog, Qgis,
)
from qgis.gui import QgsMapLayerComboBox, QgsFileWidget


# ---------------------------------------------------------------------------
# Worker thread — esegue il calcolo senza bloccare la UI
# ---------------------------------------------------------------------------

class PlannerWorker(QThread):
    progress = pyqtSignal(int)
    log      = pyqtSignal(str)
    finished = pyqtSignal(dict)
    error    = pyqtSignal(str)

    def __init__(self, params: dict):
        super().__init__()
        self.params = params

    def run(self):
        try:
            from .drone_core import run_planning, parse_kml_polygon, qgis_layer_to_polygon

            p = self.params

            # Ottieni il poligono dell'area
            if p["area_source"] == "layer":
                area_polygon = qgis_layer_to_polygon(p["area_layer"])
            else:
                area_polygon = parse_kml_polygon(p["area_kml"])

            stats = run_planning(
                dtm_path       = p["dtm_path"],
                area_polygon   = area_polygon,
                output_kml     = p["output_kml"],
                agl            = p["agl"],
                fov_deg        = p["fov"],
                overlap_pct    = p["overlap"],
                sidelap_pct    = p["sidelap"],
                step_m         = p["step"],
                smooth_m       = p["smooth"],
                heading_deg    = p["heading"],
                forced_epsg    = p["epsg"] if p["epsg"] > 0 else None,
                log_fn         = self.log.emit,
                progress_fn    = self.progress.emit,
            )
            self.finished.emit(stats)

        except Exception as e:
            self.error.emit(f"{type(e).__name__}: {e}\n\n{traceback.format_exc()}")


# ---------------------------------------------------------------------------
# Dialog principale
# ---------------------------------------------------------------------------

class DroneFlightPlannerDialog(QDialog):

    def __init__(self, iface, parent=None):
        super().__init__(parent or iface.mainWindow())
        self.iface   = iface
        self.worker  = None
        self.setWindowTitle("Drone Flight Planner")
        self.setMinimumWidth(520)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMinimizeButtonHint)
        self._build_ui()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(8)

        # Titolo
        title = QLabel("✈  Drone Flight Planner")
        font = QFont()
        font.setPointSize(13)
        font.setBold(True)
        title.setFont(font)
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)

        # Tab widget
        tabs = QTabWidget()
        main_layout.addWidget(tabs)

        tabs.addTab(self._tab_input(),  "📂  Input")
        tabs.addTab(self._tab_flight(), "🚁  Parametri volo")
        tabs.addTab(self._tab_output(), "💾  Output")

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)

        # Log
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumHeight(120)
        self.log_box.setFont(QFont("Courier", 9))
        self.log_box.setPlaceholderText("Il log di esecuzione apparirà qui...")
        main_layout.addWidget(self.log_box)

        # Pulsanti
        btn_layout = QHBoxLayout()
        self.btn_run   = QPushButton("▶  Genera piano di volo")
        self.btn_run.setStyleSheet("QPushButton { background-color: #2196F3; color: white; font-weight: bold; padding: 6px; border-radius: 4px; }"
                                   "QPushButton:hover { background-color: #1976D2; }"
                                   "QPushButton:disabled { background-color: #aaa; }")
        self.btn_close = QPushButton("Chiudi")
        btn_layout.addWidget(self.btn_run)
        btn_layout.addWidget(self.btn_close)
        main_layout.addLayout(btn_layout)

        self.btn_run.clicked.connect(self._on_run)
        self.btn_close.clicked.connect(self.close)

    def _tab_input(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setSpacing(10)

        # DTM
        grp_dtm = QGroupBox("DTM GeoTIFF")
        form_dtm = QFormLayout(grp_dtm)

        self.dtm_widget = QgsFileWidget()
        self.dtm_widget.setFilter("GeoTIFF (*.tif *.tiff);;Tutti i file (*)")
        self.dtm_widget.setFilePath("")
        form_dtm.addRow("File DTM:", self.dtm_widget)

        self.epsg_spin = QSpinBox()
        self.epsg_spin.setRange(0, 999999)
        self.epsg_spin.setValue(0)
        self.epsg_spin.setSpecialValueText("Auto")
        self.epsg_spin.setToolTip(
            "Lascia 0 per rilevamento automatico.\n"
            "Esempi: 32633 (WGS84/UTM33N), 6708 (RDN2008/UTM33N), 25833 (ETRS89/UTM33N)"
        )
        form_dtm.addRow("EPSG forzato:", self.epsg_spin)
        layout.addWidget(grp_dtm)

        # Area
        grp_area = QGroupBox("Area di rilievo")
        area_layout = QVBoxLayout(grp_area)

        # Selezione sorgente
        src_layout = QHBoxLayout()
        self.radio_layer = QCheckBox("Layer QGIS")
        self.radio_kml   = QCheckBox("File KML")
        self.radio_layer.setChecked(True)
        src_layout.addWidget(self.radio_layer)
        src_layout.addWidget(self.radio_kml)
        src_layout.addStretch()
        area_layout.addLayout(src_layout)

        # Layer combo
        self.layer_combo = QgsMapLayerComboBox()
        self.layer_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        area_layout.addWidget(self.layer_combo)

        # KML file
        self.kml_widget = QgsFileWidget()
        self.kml_widget.setFilter("KML (*.kml);;Tutti i file (*)")
        self.kml_widget.setVisible(False)
        area_layout.addWidget(self.kml_widget)

        layout.addWidget(grp_area)
        layout.addStretch()

        # Toggle sorgente area
        self.radio_layer.toggled.connect(self._toggle_area_source)
        self.radio_kml.toggled.connect(lambda checked: self.radio_layer.setChecked(not checked))

        return w

    def _tab_flight(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setSpacing(10)

        # Parametri volo
        grp_fly = QGroupBox("Parametri di volo")
        form = QFormLayout(grp_fly)

        self.agl_spin = QDoubleSpinBox()
        self.agl_spin.setRange(10, 500)
        self.agl_spin.setValue(50.0)
        self.agl_spin.setSuffix(" m")
        self.agl_spin.setDecimals(1)
        self.agl_spin.setToolTip("Quota di volo sopra il terreno (Above Ground Level)")
        form.addRow("Quota AGL:", self.agl_spin)

        self.fov_spin = QDoubleSpinBox()
        self.fov_spin.setRange(10, 180)
        self.fov_spin.setValue(70.0)
        self.fov_spin.setSuffix(" °")
        self.fov_spin.setDecimals(1)
        self.fov_spin.setToolTip("Campo visivo della fotocamera (Field of View)")
        form.addRow("FOV fotocamera:", self.fov_spin)

        self.overlap_spin = QDoubleSpinBox()
        self.overlap_spin.setRange(0, 99)
        self.overlap_spin.setValue(70.0)
        self.overlap_spin.setSuffix(" %")
        self.overlap_spin.setDecimals(0)
        self.overlap_spin.setToolTip("Sovrapposizione longitudinale tra fotogrammi")
        form.addRow("Overlap:", self.overlap_spin)

        self.sidelap_spin = QDoubleSpinBox()
        self.sidelap_spin.setRange(0, 99)
        self.sidelap_spin.setValue(70.0)
        self.sidelap_spin.setSuffix(" %")
        self.sidelap_spin.setDecimals(0)
        self.sidelap_spin.setToolTip("Sovrapposizione laterale tra strisciate")
        form.addRow("Sidelap:", self.sidelap_spin)

        layout.addWidget(grp_fly)

        # Parametri avanzati
        grp_adv = QGroupBox("Parametri avanzati")
        form2 = QFormLayout(grp_adv)

        self.step_spin = QDoubleSpinBox()
        self.step_spin.setRange(1, 50)
        self.step_spin.setValue(5.0)
        self.step_spin.setSuffix(" m")
        self.step_spin.setDecimals(1)
        self.step_spin.setToolTip("Passo di campionamento del DTM lungo le strisciate")
        form2.addRow("Passo DTM:", self.step_spin)

        self.smooth_spin = QDoubleSpinBox()
        self.smooth_spin.setRange(0, 500)
        self.smooth_spin.setValue(30.0)
        self.smooth_spin.setSuffix(" m")
        self.smooth_spin.setDecimals(0)
        self.smooth_spin.setToolTip(
            "Sigma smoothing gaussiano in metri.\n"
            "0 = disabilitato | 10 = leggero | 30 = medio | 80 = forte"
        )
        form2.addRow("Smoothing sigma:", self.smooth_spin)

        self.heading_spin = QDoubleSpinBox()
        self.heading_spin.setRange(0, 359.9)
        self.heading_spin.setValue(90.0)
        self.heading_spin.setSuffix(" °")
        self.heading_spin.setDecimals(1)
        self.heading_spin.setWrapping(True)
        self.heading_spin.setToolTip(
            "Direzione di volo delle strisciate in gradi geografici.\n"
            "0° = Nord (strisciate N-S)\n"
            "90° = Est (strisciate E-W, default)\n"
            "45° = Nord-Est\n"
            "Qualsiasi angolo è supportato."
        )
        form2.addRow("Heading strisciate:", self.heading_spin)

        layout.addWidget(grp_adv)

        # Anteprima swath
        self.swath_label = QLabel()
        self.swath_label.setStyleSheet("color: #555; font-style: italic;")
        layout.addWidget(self.swath_label)
        self._update_swath_preview()

        self.agl_spin.valueChanged.connect(self._update_swath_preview)
        self.fov_spin.valueChanged.connect(self._update_swath_preview)
        self.overlap_spin.valueChanged.connect(self._update_swath_preview)
        self.sidelap_spin.valueChanged.connect(self._update_swath_preview)

        layout.addStretch()
        return w

    def _tab_output(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setSpacing(10)

        grp = QGroupBox("File di output")
        form = QFormLayout(grp)

        self.output_widget = QgsFileWidget()
        self.output_widget.setStorageMode(QgsFileWidget.SaveFile)
        self.output_widget.setFilter("KML (*.kml)")
        self.output_widget.setFilePath("volo_drone.kml")
        form.addRow("KML output:", self.output_widget)

        self.load_layer_check = QCheckBox("Carica il KML in QGIS al termine")
        self.load_layer_check.setChecked(True)
        form.addRow("", self.load_layer_check)

        layout.addWidget(grp)
        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # Slots
    # ------------------------------------------------------------------

    def _toggle_area_source(self, use_layer: bool):
        self.layer_combo.setVisible(use_layer)
        self.kml_widget.setVisible(not use_layer)
        self.radio_kml.setChecked(not use_layer)

    def _update_swath_preview(self):
        import math
        agl  = self.agl_spin.value()
        fov  = self.fov_spin.value()
        ov   = self.overlap_spin.value()
        sl   = self.sidelap_spin.value()
        swath = 2.0 * agl * math.tan(math.radians(fov) / 2.0)
        s_sp  = swath * (1.0 - sl / 100.0)
        wp_sp = max(swath * (1.0 - ov / 100.0), 1.0)
        self.swath_label.setText(
            f"📐  Swath: {swath:.1f} m  |  "
            f"Spaziatura strisciate: {s_sp:.1f} m  |  "
            f"Dist. waypoint: {wp_sp:.1f} m"
        )

    def _on_run(self):
        # Validazione
        dtm_path = self.dtm_widget.filePath()
        if not dtm_path or not os.path.exists(dtm_path):
            self._log("❌ Seleziona un file DTM valido.")
            return

        output_kml = self.output_widget.filePath()
        if not output_kml:
            self._log("❌ Specifica il file KML di output.")
            return

        # Aggiunta estensione se mancante
        if not output_kml.lower().endswith(".kml"):
            output_kml += ".kml"

        use_layer = self.radio_layer.isChecked()
        area_layer = None
        area_kml   = None

        if use_layer:
            area_layer = self.layer_combo.currentLayer()
            if area_layer is None:
                self._log("❌ Seleziona un layer poligonale.")
                return
        else:
            area_kml = self.kml_widget.filePath()
            if not area_kml or not os.path.exists(area_kml):
                self._log("❌ Seleziona un file KML area valido.")
                return

        params = {
            "dtm_path":    dtm_path,
            "area_source": "layer" if use_layer else "kml",
            "area_layer":  area_layer,
            "area_kml":    area_kml,
            "output_kml":  output_kml,
            "agl":         self.agl_spin.value(),
            "fov":         self.fov_spin.value(),
            "overlap":     self.overlap_spin.value(),
            "sidelap":     self.sidelap_spin.value(),
            "step":        self.step_spin.value(),
            "smooth":      self.smooth_spin.value(),
            "heading":     self.heading_spin.value(),
            "epsg":        self.epsg_spin.value(),
        }

        # Avvia worker
        self.log_box.clear()
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        self.btn_run.setEnabled(False)

        self.worker = PlannerWorker(params)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.log.connect(self._log)
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.start()

    def _on_finished(self, stats: dict):
        self.btn_run.setEnabled(True)
        self.progress_bar.setValue(100)

        output_kml = self.output_widget.filePath()
        if not output_kml.lower().endswith(".kml"):
            output_kml += ".kml"

        self._log("─" * 45)
        self._log("✅  Piano di volo generato con successo!")
        self._log(f"   Strisciate    : {stats['strips']}")
        self._log(f"   Waypoint      : {stats['waypoints']}")
        self._log(f"   Quota min     : {stats['alt_min']:.1f} m s.l.m.")
        self._log(f"   Quota max     : {stats['alt_max']:.1f} m s.l.m.")
        self._log(f"   Delta terreno : {stats['alt_delta']:.1f} m")
        self._log(f"   Swath         : {stats['swath_m']:.1f} m")
        self._log(f"   CRS usato     : EPSG:{stats['epsg']}")
        self._log(f"   File salvato  : {output_kml}")

        # Carica il layer in QGIS se richiesto
        if self.load_layer_check.isChecked() and os.path.exists(output_kml):
            layer = QgsVectorLayer(output_kml, "Volo Drone", "ogr")
            if layer.isValid():
                QgsProject.instance().addMapLayer(layer)
                self._log("📍  Layer caricato in QGIS.")
            else:
                self._log("⚠️  Impossibile caricare il layer KML in QGIS.")

        self.iface.messageBar().pushMessage(
            "Drone Flight Planner",
            f"Piano di volo generato: {stats['strips']} strisciate, {stats['waypoints']} waypoint",
            level=Qgis.Success,
            duration=5,
        )

    def _on_error(self, msg: str):
        self.btn_run.setEnabled(True)
        self.progress_bar.setVisible(False)
        self._log("─" * 45)
        self._log(f"❌  ERRORE:\n{msg}")
        self.iface.messageBar().pushMessage(
            "Drone Flight Planner",
            "Errore durante la generazione. Vedi il log.",
            level=Qgis.Critical,
            duration=8,
        )

    def _log(self, msg: str):
        self.log_box.append(msg)
        self.log_box.verticalScrollBar().setValue(
            self.log_box.verticalScrollBar().maximum()
        )
        QgsMessageLog.logMessage(msg, "Drone Flight Planner", Qgis.Info)
